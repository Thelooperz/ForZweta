# Valentine's Day Card! - [Coder's way of Expressing](https://smilegupta.github.io/Valentines-Day-Card/)
 
#### Are you looking for some code to tell you Love how much you love them. Say this Valentines with the help of code.

#### Here a Live [Demo](https://smilegupta.github.io/Valentines-Day-Card/) 

### Technology Stack Used

![HTML](https://img.shields.io/badge/frontend-html-orange.svg?logo=html5&style=flat-square) 
![CSS](https://img.shields.io/badge/frontend-css-yellowgreen.svg?logo=css3&style=flat-square)
![JavaScript](https://img.shields.io/badge/frontend-javascript-yellow.svg?logo=javascript&style=flat-square)

- Front End - **HTML**, **CSS** , **JavaScript**

### Still need help?

```

  if (needHelp === true) {
     var emailId = "guptamiley3012@gmail.com";
     // email is the best way to reach out to me.
     sendEmail(emailId);
  }

```

***Glad to see you here! Show some love by [starring](https://github.com/smilegupta/faq-boxes/) this repo.***

[![Facebook](https://img.shields.io/static/v1.svg?label=follow&message=@smileguptaaa&color=grey&logo=facebook&style=flat&logoColor=white&colorA=blue)](https://www.facebook.com/smileguptaaa)  [![Instagram](https://img.shields.io/static/v1.svg?label=follow&message=@smileguptaaa&color=grey&logo=instagram&style=flat&logoColor=white&colorA=blue)](https://www.instagram.com/smileguptaaa/) [![LinkedIn](https://img.shields.io/static/v1.svg?label=connect&message=@smilegupta&color=grey&logo=linkedin&style=flat&logoColor=white&colorA=blue)](https://www.linkedin.com/in/smilegupta/) [![Twitter](https://img.shields.io/static/v1.svg?label=connect&message=@smileguptaaa&color=grey&logo=twitter&style=flat&logoColor=white&colorA=blue)](https://twitter.com/smileguptaaa)
